<a href="/">
  <img src="{{ asset('ubt.png') }}" width="100">
</a>
